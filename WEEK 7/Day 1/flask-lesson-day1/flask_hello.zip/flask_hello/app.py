import flask
# from flask import render_template_string
from flask import render_template

app = flask.Flask(__name__)


@app.route('/index')
@app.route('/index/<name>')
def index(name="Stranger"):
    return f"<h1 style='color:blue'>Hello, {name.upper()}!</h1>"


@app.route('/main/<title>')
def main(title):
	html =  render_template('main_template.html', page_title=title) #Flask automatically looks for templates in a folder called templates
	return html
	

# @app.route('/home')
# @app.route('/home/<name>')
# def home(name="Index"):
# 	project = "Coding"
# 	number = "2nd"
# 	page = '''
# 	<h1> My {{page_name}} Page </h1>
# 	<h3> This is my {{number}} flask app </h3>
# 	<p> {{thing}} is fun </p>
# 	<p> My name is  </p>
# 	'''
# 	return render_template_string(page, thing=project, number=number, page_name=name)


if __name__ == "__main__":
	app.run(debug=True)